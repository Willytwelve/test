1/  Créer la page "index.html" ( le nom "index" est utilisé par convention )
  - ajouter les img
  - ajouter les icones via https://fontawesome.com pour la recherche et la suppression
  - ajouter la police via https://fonts.google.com pour ajouter la police "open sans"
  <!-- 
    Url de la police pour aller plus vite !
    - ajouter la police Open Sans via https://fonts.google.com/?query=open+sans&selection.family=Open+Sans  
  -->

2/ Ajouter le style
  - utiliser le display flex ou grid // C'est plus rapide !

3/ Ajouter le fichier "main.js" dans la page html
  - Soit dans la balise Head, soit dans la balise Body de la page index.html

4/ Pouvoir supprimer/ajuouter un contact et filtrer un contact en entrant le nom du contact dans le formulaire de recherche en javascript uniquement